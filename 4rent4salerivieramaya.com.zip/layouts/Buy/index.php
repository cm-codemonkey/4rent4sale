<?php defined('_EXEC') or die; ?>
<header class="main-header">
    %{header}%
</header>
<section class="buy-process-background" data-image-src="{$background_buy}">
    <div class="content">
        <h1>{$title}</h1>
    </div>
</section>
<section class="buy-process-content">
    <div class="container">
        {$buy_process}
    </div>
</section>
