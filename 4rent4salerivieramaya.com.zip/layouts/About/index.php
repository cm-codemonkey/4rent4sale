<?php defined('_EXEC') or die; ?>
<header class="main-header">
    %{header}%
</header>
<section class="about-us-background" data-image-src="{$background_about}">
    <div class="content">
        <h1>{$title}</h1>
    </div>
</section>
<section class="about-content">
    <div class="container">
        {$about}
    </div>
</section>
