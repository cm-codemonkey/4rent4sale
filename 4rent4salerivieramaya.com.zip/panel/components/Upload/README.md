# upload.class.php
Clase para subir ficheros en Valkyrie Platform.
