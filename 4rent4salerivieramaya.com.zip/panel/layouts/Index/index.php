<?php defined('_EXEC') or die; ?>
<header class="topbar">
    %{topbar}%
</header>
<section class="sidebar">
    %{sidebar}%
</section>
<section class="main-content">
    <div class="container">
        <!-- <h4><i class="material-icons">people</i> Usuarios</h4>
        <div class="table-responsive-vertical">
            <table class="table table-hover table-mc-light-blue">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Ticket</th>
                        <th>Sala</th>
                        <th>Fecha y Hora</th>
                        <th>Estado</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {$reservationsList}
                </tbody>
            </table>
        </div>

        {$pager} -->
    </div>
</section>
